package DTO;

public class OrderDTO {

}
